﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1
{

    public static class ClassesManage
    {
        static DataBaseConnection database = new DataBaseConnection();
        public static void insertClass(string class_name,string class_code,string class_desc,string userid)
        {
            string table_name = "classes";
            string[] columns = { "class_name", "class_code", "description", "user_id" };
            string[] values = { class_name, class_code, class_desc, userid };
            database.Insert(table_name, columns, values);
        }
        public static string GetCLassIDByCode(string code)
        {
            string table_name = "classes";
            string[] columns = { "id"};
            string cond = "class_code='" + code + "'";
            var data=database.Select(table_name, columns, cond);
            if (data.Length == 1)
                return data[0][0].ToString();
            else
                return "";
        }
        public static void InsertUsersCLasses(string classid,string userid)
        {
            string table_name = "users_classes";
            string[] columns = { "classid","userid" };
            string[] values = { classid, userid };
            database.Insert(table_name, columns, values);
        }
        public static object[][] GetUserClasses(string verifier)
        {
            string table_name = "classes inner join users_classes on(classes.id=users_classes.classid) inner join users on(users.id=users_classes.userid) ";
            string[] columns = { "classes.id" ,"class_name","class_code", "description","date_inserted" };
            string cond = "verifier='" + verifier + "'";
            var data = database.Select(table_name, columns, cond);
            return data;
        }
        public static object[][] UserCanAccessToClass(string verifier,string classid)
        {
            string table_name = "classes inner join users_classes on(classes.id=users_classes.classid) inner join users on(users.id=users_classes.userid) ";
            string[] columns = { "classes.id", "class_name", "class_code", "description", "date_inserted" };
            string cond = "verifier='" + verifier + "' and users_classes.classid='"+classid+"'";
            var data = database.Select(table_name, columns, cond);
            return data;
        }

    }
}