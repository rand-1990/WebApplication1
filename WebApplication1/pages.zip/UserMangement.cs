﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace WebApplication1
{
    public static class UserMangement
    {
       public static void sendmail(string to_email,string username,string message_random)
        {

            var fromAddress = new MailAddress("rand6101990@gmail.com", "Al-Mustansryah online portal");
            var toAddress = new MailAddress(to_email, username);
            const string fromPassword = "randrand";
            const string subject = "registeration code";
             string body ="welcome to AL-Mustansryah Portal,the code is : "+ message_random;

            var smtp = new SmtpClient
            {
                Host = "smtp.gmail.com",
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(fromAddress.Address, fromPassword)
            };
            using (var message = new MailMessage(fromAddress, toAddress)
            {
                Subject = subject,
                Body = body
            })
            {
                smtp.Send(message);
            }
        }
       static DataBaseConnection condb = new DataBaseConnection();

        public static bool isLecture(string verifier)
        {
            string table_name = "users";
            string[] columns = { "type"};
            string condition = "verifier='" + verifier + "'";
            var data = condb.Select(table_name, columns, condition);
            if (data[0][0].ToString() == "1")
                return true;
            else return false;
        }
        public static int getUserID(string verifier)
        {
            string table_name = "users";
            string[] columns = { "id" };
            string condition = "verifier='" + verifier + "'";
            var data = condb.Select(table_name, columns, condition);
            return Int32.Parse(data[0][0].ToString());
        }
        public static bool check_info_lecture(int id)
        {
            string table_name = "teacher";
            string[] columns = { "user_id" };
            string condition = "user_id='" + id + "'";
            var data = condb.Select(table_name, columns, condition);
            if (data.Length == 1)
                return true;
            else
                return false;
        }




        public static bool isStudent(string verifier)
        {
            string table_name = "users";
            string[] columns = { "type" };
            string condition = "verifier='" + verifier + "'";
            var data = condb.Select(table_name, columns, condition);
            if (data[0][0].ToString() == "2")
                return true;
            else return false;
        }

        public static bool check_info_student(int id)
        {
            string table_name = "student";
            string[] columns = { "user_id" };
            string condition = "user_id='" + id + "'";
            var data = condb.Select(table_name, columns, condition);
            if (data.Length == 1)
                return true;
            else
                return false;
        }

    }
}