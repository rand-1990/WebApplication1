﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class classes_show : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
  
            var data= ClassesManage.GetUserClasses(Session["verifier"].ToString());
            string value = "";
            for(int i=0;i<data.Length;i++)
            {
                value += "<div class='col'>";
                value += "<div class='card h-100'>";
                value += "<img src = 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Logoo2.png/200px-Logoo2.png'class='card-img-top'/>";
                value += "<div class='card-body'>";
                value += "<h5 class='card-title'>"+data[i][1].ToString()+"</h5>";
                value += "<p class='card-text'>";
                value += data[i][3].ToString();
                value += "</p><a href='class_post.aspx?id="+data[i][0].ToString()+"'>go</a></div></div></div>";
            }
            maindiv.InnerHtml = value;
        }
    }
}